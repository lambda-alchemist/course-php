<?php

// Project Gutenberg License
// source: https://www.gutenberg.org/files/8789/8789-h/8789-h.htm
$text = array(
"IN the midway of this our mortal life,",
"I found me in a gloomy wood, astray",
"Gone from the path direct: and e'en to tell",
"It were no easy task, how savage wild",
"That forest, how robust and rough its growth,",
"Which to remember only, my dismay",
"Renews, in bitterness not far from death.",
"Yet to discourse of what there good befell,",
"All else will I relate discover'd there.",
"How first I enter'd it I scarce can say,",
"Such sleepy dullness in that instant weigh'd",
"My senses down, when the true path I left,",
"But when a mountain's foot I reach'd, where clos'd",
"The valley, that had pierc'd my heart with dread,",
"I look'd aloft, and saw his shoulders broad",
"Already vested with that planet's beam,",
"Who leads all wanderers safe through every way.",

"Then was a little respite to the fear,",
"That in my heart's recesses deep had lain,",
"All of that night, so pitifully pass'd:",
"And as a man, with difficult short breath,",
"Forespent with toiling, 'scap'd from sea to shore,",
"Turns to the perilous wide waste, and stands",
"At gaze; e'en so my spirit, that yet fail'd",
"Struggling with terror, turn'd to view the straits,",
"That none hath pass'd and liv'd.  My weary frame",
"After short pause recomforted, again",
"I journey'd on over that lonely steep,", );

// q02
echo "\n\n";
$i = 0;
$user = 16; //faux user input
while($i <= $user){
	echo $text[$i]."\n";
	$i++;
}

