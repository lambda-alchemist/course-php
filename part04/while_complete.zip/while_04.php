<?php

// q04
$i = 0;
while($i <= 100){
	echo "$i"; $i++;
	if($i % 10)
		{ echo"  "; }
	else
		{ echo"\n"; }
}
echo"\n"; 
