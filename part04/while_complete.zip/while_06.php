<?php

// q06
$i = 500;
while($i >= 10){
	if($i % 2)
		{ echo"\n"; }
	else
		{ echo"$i"; }
	$i--;
}
echo "\n";
