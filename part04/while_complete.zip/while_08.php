<?php

// q08
$i = 0; $sum = 0; $user = 36;// faux user input
while($i <= $user){
	$sum += $i;
	$i++;
}
echo"$sum\n";
