<?php

// q10
$x = 0;
while($x <= 1000){
	$x += rand(0, 100);
	echo"$x\n";
}

