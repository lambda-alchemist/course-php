<?php

// q09
$i = 1;
while($i){
	$x = rand(0, 50);
	echo"$x\n";
	if($x == 37) {
		$i = 0;
	}
}
