<?php

// q03
echo "\n\n";
$i = 0;
while($i <= 10){
	echo "$i\n";
	$i++;
}

