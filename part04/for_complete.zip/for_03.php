<?php

for ( $i = 0 ; $i <= 100 ; $i++ ){
	if( $i % 3 ) { } else {
		echo"$i\n";
	}
}

?>
