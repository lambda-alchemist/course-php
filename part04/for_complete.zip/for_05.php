<?php

for ( $i = 500 ; $i >= 10 ; $i-- ){
	echo"$i\n";
}

?>
